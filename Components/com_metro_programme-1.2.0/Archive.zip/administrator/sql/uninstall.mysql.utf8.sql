DROP TABLE IF EXISTS `#__metro_programme`;
