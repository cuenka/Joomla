DROP TABLE IF EXISTS `#__speaker`;
