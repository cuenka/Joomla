<?php
/**
 * @version     1.0.6
 * @package     com_speakers
 * @copyright   Jose Cuenca - 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Jose Cuenca <jose@aviationmedia.aero> - http://www.aviationmedia.aero
 */
// no direct access
defined('_JEXEC') or die;

//Load admin language file
$lang = JFactory::getLanguage();
$lang->load('com_speakers', JPATH_ADMINISTRATOR);
$canEdit = JFactory::getUser()->authorise('core.edit', 'com_speakers.' . $this->item->id);
if (!$canEdit && JFactory::getUser()->authorise('core.edit.own', 'com_speakers' . $this->item->id)) {
	$canEdit = JFactory::getUser()->id == $this->item->created_by;
}
?>
<?php if ($this->item) : ?>

    <div class="item_fields">

        <ul class="fields_list">

            			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_ID'); ?>:
			<?php echo $this->item->id; ?></li>
			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_ORDERING'); ?>:
			<?php echo $this->item->ordering; ?></li>
			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_STATE'); ?>:
			<?php echo $this->item->state; ?></li>
			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_CHECKED_OUT'); ?>:
			<?php echo $this->item->checked_out; ?></li>
			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_CHECKED_OUT_TIME'); ?>:
			<?php echo $this->item->checked_out_time; ?></li>
			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_CREATED_BY'); ?>:
			<?php echo $this->item->created_by; ?></li>
			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_NAME'); ?>:
			<?php echo $this->item->name; ?></li>
			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_SURNAME'); ?>:
			<?php echo $this->item->surname; ?></li>
			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_INTRO_BIOGRAPHY'); ?>:
			<?php echo $this->item->intro_biography; ?></li>
			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_FULL_BIOGRAPHY'); ?>:
			<?php echo $this->item->full_biography; ?></li>
			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_JOB_TITLE'); ?>:
			<?php echo $this->item->job_title; ?></li>
			<li><?php echo JText::_('COM_SPEAKERS_FORM_LBL_SPEAKER_PHOTO'); ?>:
			<?php echo $this->item->photo; ?></li>


        </ul>

    </div>
    <?php if($canEdit && $this->item->checked_out == 0): ?>
		<a href="<?php echo JRoute::_('index.php?option=com_speakers&task=speaker.edit&id='.$this->item->id); ?>"><?php echo JText::_("COM_SPEAKERS_EDIT_ITEM"); ?></a>
	<?php endif; ?>
								<?php if(JFactory::getUser()->authorise('core.delete','com_speakers.speaker.'.$this->item->id)):
								?>
									<a href="javascript:document.getElementById('form-speaker-delete-<?php echo $this->item->id ?>').submit()"><?php echo JText::_("COM_SPEAKERS_DELETE_ITEM"); ?></a>
									<form id="form-speaker-delete-<?php echo $this->item->id; ?>" style="display:inline" action="<?php echo JRoute::_('index.php?option=com_speakers&task=speaker.remove'); ?>" method="post" class="form-validate" enctype="multipart/form-data">
										<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />
										<input type="hidden" name="option" value="com_speakers" />
										<input type="hidden" name="task" value="speaker.remove" />
										<?php echo JHtml::_('form.token'); ?>
									</form>
								<?php
								endif;
							?>
<?php
else:
    echo JText::_('COM_SPEAKERS_ITEM_NOT_LOADED');
endif;
?>
