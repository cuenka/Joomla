DROP TABLE IF EXISTS `#__download_`;
