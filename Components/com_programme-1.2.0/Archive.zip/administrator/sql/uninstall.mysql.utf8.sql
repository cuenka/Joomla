DROP TABLE IF EXISTS `#__com_programme`;
