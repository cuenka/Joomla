DROP TABLE IF EXISTS `#__floorplan_booth`;
