DROP TABLE IF EXISTS `#__available_assets_msns`;
