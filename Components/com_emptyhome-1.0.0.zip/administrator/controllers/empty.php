<?php
/**
 * @version     1.0.0
 * @package     com_emptyhome
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Jose <jose@aviationmedia.aero> - http://www.aviationmedia.aero
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Empty controller class.
 */
class EmptyhomeControllerEmpty extends JControllerForm
{

    function __construct() {
        $this->view_list = 'emptys';
        parent::__construct();
    }

}