DROP TABLE IF EXISTS `#__meettheteam_employee`;
