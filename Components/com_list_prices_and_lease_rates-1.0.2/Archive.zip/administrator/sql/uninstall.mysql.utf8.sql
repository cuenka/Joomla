DROP TABLE IF EXISTS `#__com_list_prices_and_lease_rate`;
