DROP TABLE IF EXISTS `#__supporters_list`;
