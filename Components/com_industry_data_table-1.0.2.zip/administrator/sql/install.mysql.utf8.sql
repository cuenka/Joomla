CREATE TABLE IF NOT EXISTS `#__industry_data_table_aircraft_deals` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`asset_id` INT(10) UNSIGNED NOT NULL DEFAULT '0',

`ordering` INT(11)  NOT NULL ,
`state` TINYINT(1)  NOT NULL ,
`checked_out` INT(11)  NOT NULL ,
`checked_out_time` DATETIME NOT NULL DEFAULT '0000-00-00 00:00:00',
`created_by` INT(11)  NOT NULL ,
`msn` VARCHAR(255)  NOT NULL ,
`manufacturer` VARCHAR(255)  NOT NULL ,
`model` VARCHAR(255)  NOT NULL ,
`event` VARCHAR(255)  NOT NULL ,
`owner` VARCHAR(255)  NOT NULL ,
`operator` VARCHAR(255)  NOT NULL ,
`date` DATE NOT NULL DEFAULT '2014-01-01',
PRIMARY KEY (`id`)
) DEFAULT COLLATE=utf8_general_ci;

