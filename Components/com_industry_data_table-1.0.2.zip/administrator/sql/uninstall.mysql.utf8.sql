DROP TABLE IF EXISTS `#__industry_data_table_aircraft_deals`;
