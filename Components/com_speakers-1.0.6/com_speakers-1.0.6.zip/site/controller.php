<?php
/**
 * @version     1.0.6
 * @package     com_speakers
 * @copyright   Jose Cuenca - 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Jose Cuenca <jose@aviationmedia.aero> - http://www.aviationmedia.aero
 */
 
// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controller');

class SpeakersController extends JControllerLegacy
{

}