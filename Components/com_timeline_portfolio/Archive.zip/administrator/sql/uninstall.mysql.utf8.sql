DROP TABLE IF EXISTS `#__timeline_portfolio`;
