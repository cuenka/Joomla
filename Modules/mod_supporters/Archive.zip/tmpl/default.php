<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>


</div>

<?php foreach ($supporters as $supporter) : ?>
<div class="sponsors-home">
	<a href="http://www.interairport.com/europe/english/" target="_blank" title="Inter" airport="" europe="" rel="follow">
		<img alt="smart-interairport" src="/China/images/sponsors/2013/smart-interairport.gif" 110px="" height:="" 80px="" width="110" height="80">
	</a>
</div>
<?php endforeach; ?>
