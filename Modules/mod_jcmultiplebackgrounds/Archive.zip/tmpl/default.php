<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>
<style>
body {
  background:url('<?php echo $background; ?>') <?php echo $params->get('bgcolour'); ?> no-repeat 50% 50% !important;
  background-attachment: fixed !important;
  -webkit-background-size: cover !important;
  -moz-background-size: cover !important;
  background-size: cover!important;
  padding: 0 !important;;
  margin: 0 !important;;
  border: 0 !important;;
}
</style>